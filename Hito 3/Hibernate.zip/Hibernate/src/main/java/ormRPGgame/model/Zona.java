package ormRPGgame.model;

import javax.persistence.*;
@Entity
@Table(name="Zona")
public class Zona {
    @Id
    @Column(name="ID_Zona")
    private String ID_Zona;

}
