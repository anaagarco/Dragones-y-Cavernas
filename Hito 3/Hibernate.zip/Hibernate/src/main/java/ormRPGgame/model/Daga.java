package ormRPGgame.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;
@Entity
@Table(name="Daga")
public class Daga {
    @Id
    @Column(name="ID_Daga")
    private Long ID_Daga;
    @Column(name="danio",nullable=false)
    private Integer danio;
    @ManyToMany(mappedBy=ID_Daga)
    private set <Tienda> nombre_t;
    //falta 1:1
    public Daga(String nombre){
        // @TODO completar el constructor de la clase.
    }

    public String getnombre(){ return this.name;}
}
