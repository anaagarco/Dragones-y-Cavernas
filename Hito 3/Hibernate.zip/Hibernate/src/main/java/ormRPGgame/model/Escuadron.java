package ormRPGgame.model;

import javax.persistence.*;

@Entity
@Table(name="escuadron")
public class Escuadron {
    @Id
    @Column(name="id_e",nullable = false)
    @ManyToMany(mappedBy=id_m)
    private set <Escuadron> Escuadrones;
    @ManyToMany(mappedBy=id_t)
    private set <Escuadron> Escuadrones;
    @ManyToMany(mappedBy=id_g)
    private set <Escuadron> Escuadrones;
    //La key es de tipo string pero es un numero ,la dejo de string o
    //por ser un numero deberia ponerla de long
    private long id_e;
}
