package ormRPGgame.model;
import javax.persistence.*;
@Entity
@Table(name="Ciudad")
public class Ciudad {
    @Id
    @Column(name="nombre_c")
    private String nombre_c;
    @ManyToOne(optional = false)
    @JoinColumn(name="ID_Zona")
    private Zona ID_Zona;
}
